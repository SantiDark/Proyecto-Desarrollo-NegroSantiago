using UnityEngine;
using UnityEngine.UI;

public class PlayerHUD : MonoBehaviour
{
    [Header("Referencias")]
    public Health playerHealth;
    public PlayerController playerController;

    [Header("UI")]
    public Slider healthSlider;
    public Slider staminaSlider;

    void Start()
    {
        if (playerHealth && healthSlider)
        {
            healthSlider.minValue = 0f;
            healthSlider.maxValue = playerHealth.maxHealth;
            healthSlider.value = playerHealth.CurrentHealth;
            playerHealth.OnHealthChanged += OnHealthChanged;
        }
        if (playerController && staminaSlider)
        {
            staminaSlider.minValue = 0f;
            staminaSlider.maxValue = playerController.maxStamina;
            staminaSlider.value = playerController.GetStamina();
        }
    }

    void OnDestroy()
    {
        if (playerHealth) playerHealth.OnHealthChanged -= OnHealthChanged;
    }

    void Update()
    {
        if (playerController && staminaSlider)
            staminaSlider.value = playerController.GetStamina();
    }

    void OnHealthChanged(float current, float max)
    {
        if (!healthSlider) return;
        healthSlider.maxValue = max;
        healthSlider.value = current;
    }
}
