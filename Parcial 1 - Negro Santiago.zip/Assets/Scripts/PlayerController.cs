﻿using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Movimiento")]
    public float moveSpeed = 5f;          
    public float gravity = -9.81f;      

    [Header("Estamina (consigna)")]
    public float maxStamina = 10f; // tope 10
    public float staminaRegenPerSec = 1f;  // +1/s constante
    public float proximityDrainPerSec = 1f;  // -1/s cuando te persigue/ve el enemigo

    // Lectura pública (solo lectura)
    public float CurrentStamina { get; private set; }

    // Internos
    private CharacterController cc;
    private Vector3 vel;               // componente vertical/gravedad
    private bool drainedThisFrame;     // si drenamos este frame
    private bool regenPaused;          // << NUEVO: pausa explícita de la regeneración

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        CurrentStamina = maxStamina;  // arranca lleno (10)
    }

    void Update()
    {
        // --- Movimiento en plano según la rotación actual del Player ---
        float h = Input.GetAxis("Horizontal"); // A/D
        float v = Input.GetAxis("Vertical");   // W/S

        Vector3 move = (transform.forward * v + transform.right * h);
        if (move.sqrMagnitude > 0.001f)
        {
            cc.Move(move.normalized * moveSpeed * Time.deltaTime);
        }

        // --- Gravedad ---
        if (cc.isGrounded && vel.y < 0f) vel.y = -2f; // pegado al suelo
        vel.y += gravity * Time.deltaTime;
        cc.Move(vel * Time.deltaTime);

        // --- Estamina ---
        // Si la regen está PAUSADA (enemigo te detecta) o drenamos este frame, no regenerar.
        if (!regenPaused && !drainedThisFrame)
            CurrentStamina = Mathf.Min(maxStamina, CurrentStamina + staminaRegenPerSec * Time.deltaTime);

        drainedThisFrame = false; // reset para el próximo frame

     
    }

    /// Llamado por el Enemigo cada frame que te persigue/ve. Drena 1/s (o lo configurado).
    public void DrainStamina(float dt)
    {
        drainedThisFrame = true;
        CurrentStamina = Mathf.Max(0f, CurrentStamina - proximityDrainPerSec * dt);
    }

    /// NUEVO: pausa/reanuda la regeneración (lo llama el EnemyAI cuando te detecta / deja de detectar).
    public void SetRegenPaused(bool paused) => regenPaused = paused;

    // Helpers para HUD/debug
    public float GetStamina() => CurrentStamina;
    public float GetStamina01() => CurrentStamina / Mathf.Max(0.0001f, maxStamina);
}
