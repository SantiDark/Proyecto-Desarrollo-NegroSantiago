using UnityEngine;
using System;

public class Health : MonoBehaviour
{
    [Header("Vida (regulable)")]
    public float maxHealth = 100f;

    public float CurrentHealth { get; private set; }

    public Action OnDeath;
    public Action<float, float> OnHealthChanged; // (current, max)

    void Awake()
    {
        CurrentHealth = maxHealth;
        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    public void TakeDamage(float amount)
    {
        if (CurrentHealth <= 0f) return;

        CurrentHealth = Mathf.Max(0f, CurrentHealth - amount);
        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);

        // Aviso opcional a quien tenga ese m�todo (EnemyAI u otro). 
        // No rompe si no existe.
        SendMessageUpwards("NotifyDamageTaken", SendMessageOptions.DontRequireReceiver);

        if (CurrentHealth <= 0f)
            OnDeath?.Invoke();
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
