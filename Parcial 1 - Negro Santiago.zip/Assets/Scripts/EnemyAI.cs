using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public enum State { Normal, Chase, Damage, Dead }

    [Header("Referencias")]
    public Transform player;
    public Health health;
    public CharacterController controller; // Me lo recomend� GPT pero no lo us�, lo dejo por las dudas

    [Header("Movimiento")]
    public float moveSpeed = 3.5f;
    [Tooltip("Distancia m�nima para no meterse dentro del Player (evita empujar)")]
    public float stopDistance = 1.2f;

    [Header("Persecuci�n por distancia (nota 4)")]
    public float chaseDistance = 5f;   // regulable

    [Header("Cono de visi�n (7�10)")]
    public bool useVisionCone = true;
    public float visionAngle = 60f;    // medio �ngulo
    public float visionDistance = 12f; // alcance

    [Header("Colisi�n")]
    [Tooltip("Convierte todos los Colliders del Enemigo en triggers al iniciar para no empujar al Player.")]
    public bool makeCollidersTriggersAtStart = true;

    private Vector3 spawnPos;
    private Quaternion spawnRot;
    private State state = State.Normal;

    void Awake()
    {
        if (!health) health = GetComponent<Health>();
        spawnPos = transform.position;
        spawnRot = transform.rotation;
        if (health != null) health.OnDeath += OnDead;
    }

    void Start()
    {
        // Referencia al Player por Tag
        if (!player)
        {
            var go = GameObject.FindGameObjectWithTag("Player");
            if (go) player = go.transform;
        }

        // En un momento me empez� a empukar al player as� que puse esto:
        if (makeCollidersTriggersAtStart)
            MakeAllCollidersTriggers();

        LogState(state);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F3))
        {
            RespawnAtSpawn();
            return;
        }

        if (state == State.Dead || !player) return;

        float dist = Vector3.Distance(transform.position, player.position);
        bool inRadius = dist <= chaseDistance;
        bool inCone = useVisionCone && IsInVisionCone();

        if (inRadius || inCone)
        {
            SetState(State.Chase);
            Chase(Time.deltaTime, dist);

            // - ESTAMINA
            var pc = player.GetComponent<PlayerController>();
            if (pc != null)
            {
                pc.SetRegenPaused(true);                  // << pausa la regeneraci�n mientras te detecta
                pc.DrainStamina(Time.deltaTime);          // drena 1 por segundo
            }
        }
        else
        {
            SetState(State.Normal);

            // reanuda la regeneraci�n cuando NO te detecta
            var pc = player.GetComponent<PlayerController>();
            if (pc != null) pc.SetRegenPaused(false);
        }
    }

    bool IsInVisionCone()
    {
        Vector3 toP = player.position - transform.position;
        toP.y = 0f;
        if (toP.magnitude > visionDistance) return false;
        Vector3 fwd = transform.forward; fwd.y = 0f;
        return Vector3.Angle(fwd, toP) <= visionAngle;
    }

    void Chase(float dt, float currentDist)
    {
        // NO EMPUJA AL JUGADOR
        if (currentDist <= stopDistance) return;

        Vector3 dir = (player.position - transform.position);
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.0001f) return;

        // Mirar hacia el jugador
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10f * dt);

        // Mover (con CC si est� asignado, o por transform si no)
        Vector3 step = dir.normalized * moveSpeed * dt;
        if (controller != null) controller.Move(step);
        else transform.position += step;
    }
    // MUERE
    void OnDead()
    {
        // reanuda la regeneraci�n por las dudas si muere mientras te ve
        var pc = player ? player.GetComponent<PlayerController>() : null;
        if (pc != null) pc.SetRegenPaused(false);

        CancelInvoke(nameof(ReturnToChaseOrNormal));      // << NUEVO: evitar que un Invoke pendiente cambie el estado

        SetState(State.Dead);
        if (controller) controller.enabled = false;
        ToggleColliders(false);
        ToggleRenderers(false); // desaparece
    }

    public void NotifyDamageTaken()
    {
        if (state == State.Dead) return;
        SetState(State.Damage);
        CancelInvoke(nameof(ReturnToChaseOrNormal));
        Invoke(nameof(ReturnToChaseOrNormal), 0.2f);
    }

    void ReturnToChaseOrNormal()
    {
        if (state == State.Dead) return;                  // << NUEVO: si est� muerto no tocar el estado
        bool chase = Vector3.Distance(transform.position, player.position) <= chaseDistance
                     || (useVisionCone && IsInVisionCone());
        SetState(chase ? State.Chase : State.Normal);
    }

    public void RespawnAtSpawn()
    {
        transform.position = spawnPos;
        transform.rotation = spawnRot;
        transform.localScale = Vector3.one;

        ToggleColliders(true);
        if (makeCollidersTriggersAtStart) MakeAllCollidersTriggers();
        if (controller) controller.enabled = true;
        ToggleRenderers(true);

        if (health != null) health.ResetHealth();

        // asegurar que la regeneraci�n quede reanudada al respawnear
        var pc = player ? player.GetComponent<PlayerController>() : null;
        if (pc != null) pc.SetRegenPaused(false);

        SetState(State.Normal);
        Debug.Log("[Enemy] Respawned at original position (F3).");
    }

    void OnDisable()
    {
        // failsafe: si se desactiva por cualquier motivo, reanudar la regeneraci�n
        var pc = player ? player.GetComponent<PlayerController>() : null;
        if (pc != null) pc.SetRegenPaused(false);
    }

    void SetState(State s)
    {
        if (state == s) return;
        state = s;
        LogState(state);
    }

    void LogState(State s) => Debug.Log($"[Enemy State] {s.ToString().ToLower()}");


    void ToggleRenderers(bool enabled)
    {
        var rends = GetComponentsInChildren<Renderer>(true);
        foreach (var r in rends) r.enabled = enabled;
    }

    void ToggleColliders(bool enabled)
    {
        var cols = GetComponentsInChildren<Collider>(true);
        foreach (var c in cols) c.enabled = enabled;
    }

    void MakeAllCollidersTriggers()
    {
        var cols = GetComponentsInChildren<Collider>(true);
        foreach (var c in cols) c.isTrigger = true;
    }

    // CONO
    void OnDrawGizmosSelected()
    {
        if (!useVisionCone) return;
        Gizmos.color = Color.yellow;
        Vector3 o = transform.position;
        Vector3 f = transform.forward; f.y = 0f; f.Normalize();
        int steps = 20;
        Vector3 prev = o + Quaternion.AngleAxis(-visionAngle, Vector3.up) * f * visionDistance;
        for (int i = 1; i <= steps; i++)
        {
            float t = Mathf.Lerp(-visionAngle, visionAngle, i / (float)steps);
            Vector3 cur = o + Quaternion.AngleAxis(t, Vector3.up) * f * visionDistance;
            Gizmos.DrawLine(o, cur);
            Gizmos.DrawLine(prev, cur);
            prev = cur;
        }
    }
}
